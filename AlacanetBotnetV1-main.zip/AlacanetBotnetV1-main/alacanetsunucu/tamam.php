<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="0;icerik.php">
</head>
<body>

<form action="">
<script language="javascript">
confirm("Saldırı başladı. Anasayfaya gitmek için tamam butonuna basınız.")
</script>
</form>

</body>
</html>